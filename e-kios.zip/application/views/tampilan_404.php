<div class="slider-container" style="height:100px;">
</div>

<div role="main" class="main">

				<section class="page-header">
					<div class="container">
						<div class="row">
							<div class="col-md-12">
								<ul class="breadcrumb">
									<li><a href="#">Home</a></li>
									<li class="active">Pages</li>
								</ul>
							</div>
						</div>
						<div class="row">
							<div class="col-md-12">
								<h1 style="margin: 0 0 -12px;">404 - Page Not Found</h1>
                <br>
							</div>
						</div>
					</div>
				</section>
        <div class="container">

					<section class="page-not-found">
						<div class="row">
								<div class="page-not-found-main">
                  <center>
  									<h2>404 <i class="fa fa-file"></i></h2>
  									<p>Halaman yang anda cari tidak ada.</p>
                  </center>
								</div>

						</div>
					</section>

				</div>
      </div>
